<?php

$lang['migration_none_found']			= "找不到任何迁移.";
$lang['migration_not_found']			= "找不到该迁移.";
$lang['migration_multiple_version']		= "这个多重迁移版本号是: %d.";
$lang['migration_class_doesnt_exist']	= "找不到该迁移类 \"%s\".";
$lang['migration_missing_up_method']	= "该迁移类缺少'up'方法.";
$lang['migration_missing_down_method']	= "该迁移类缺少'downd'方法.";
$lang['migration_invalid_filename']		= "迁移 \"%s\" 文件名无效.";


/* End of file migration_lang.php */
/* Location: ./application/language/english/migration_lang.php */
